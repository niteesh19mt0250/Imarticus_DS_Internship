import streamlit as st
import faiss
import pickle
import numpy as np
from sentence_transformers import SentenceTransformer
from transformers import pipeline

# Load FAISS index and metadata
index = faiss.read_index("faiss_index/index.faiss")

with open("faiss_index/chunks.pkl", "rb") as f:
    chunks = pickle.load(f)

with open("faiss_index/meta.pkl", "rb") as f:
    sources = pickle.load(f)

# Load models
embed_model = SentenceTransformer("all-MiniLM-L6-v2")
qa_model = pipeline("question-answering", model="distilbert-base-uncased-distilled-squad")

# Streamlit UI
st.set_page_config(page_title="PDF Q&A Chatbot", layout="wide")
st.title("PDF Q&A Chatbot")
st.write("Ask anything based on Python, SQL, or Machine Learning documents.")

# Topic filter
selected_topic = st.selectbox("Search in:", ["All", "python.pdf", "sql.pdf", "ml.pdf"])

# Question input
question = st.text_input("Enter your question")

if question:
    # Embed question
    q_embedding = embed_model.encode([question])
    q_embedding = np.array(q_embedding).astype("float32")

    # Search top 5 chunks
    top_k = 5
    distances, indices = index.search(q_embedding, top_k)

    # Filter by document
    context = ""
    used_sources = {}
    for i in indices[0]:
        if selected_topic == "All" or sources[i] == selected_topic:
            context += chunks[i] + "\n"
            used_sources[int(i)] = sources[i]

    if not context:
        st.warning("No relevant content found in the selected document.")
    else:
        # Get answer from model
        result = qa_model(question=question, context=context)
        st.subheader("Answer")
        st.success(result["answer"].strip())

        # Optional context and sources
        with st.expander("Context Used"):
            st.write(context[:1500] + "..." if len(context) > 1500 else context)

        with st.expander("Sources"):
            st.write(used_sources)
