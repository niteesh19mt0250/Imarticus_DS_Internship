import os
import fitz  
import faiss
import pickle
from sentence_transformers import SentenceTransformer
from sklearn.preprocessing import normalize
import numpy as np

# Step 1: Load and read PDFs from 'docs/'
def extract_text_from_pdfs(folder_path):
    all_chunks = []
    file_paths = []

    for filename in os.listdir(folder_path):
        if filename.endswith(".pdf"):
            path = os.path.join(folder_path, filename)
            doc = fitz.open(path)
            text = ""

            for page in doc:
                text += page.get_text()

            # Split text into 500-character chunks
            chunks = [text[i:i+500] for i in range(0, len(text), 500)]
            all_chunks.extend(chunks)
            file_paths.extend([filename] * len(chunks))

    return all_chunks, file_paths

# Step 2: Create embeddings using HuggingFace
def embed_chunks(chunks):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(chunks, convert_to_tensor=False)
    return np.array(embeddings)

# Step 3: Save into FAISS index
def create_faiss_index(embeddings):
    embeddings = normalize(embeddings)  
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    return index

# Step 4: Save everything
def save_index(index, chunks, file_paths):
    faiss.write_index(index, "faiss_index/index.faiss")
    with open("faiss_index/chunks.pkl", "wb") as f:
        pickle.dump(chunks, f)
    with open("faiss_index/meta.pkl", "wb") as f:
        pickle.dump(file_paths, f)

# Main flow
if __name__ == "__main__":
    print("Extracting text from PDFs...")
    chunks, sources = extract_text_from_pdfs("docs")

    print("Generating embeddings...")
    embeddings = embed_chunks(chunks)

    print("Building FAISS index...")
    index = create_faiss_index(embeddings)

    print("Saving index and data...")
    os.makedirs("faiss_index", exist_ok=True)
    save_index(index, chunks, sources)

    print("PDF indexing complete. FAISS DB is ready.")
