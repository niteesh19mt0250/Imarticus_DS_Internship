import streamlit as st
import pandas as pd
import numpy as np
import joblib
import faiss
import pickle
from sentence_transformers import SentenceTransformer
from transformers import pipeline
import altair as alt

# SETUP PAGE 
st.set_page_config(page_title="ML Dashboard & PDF Chatbot", layout="wide")
st.title("ML Dashboard & PDF Chatbot")
tab1, tab2 = st.tabs(["Dashboard", "Chatbot"])

# TAB 1: ML DASHBOARD 
with tab1:
    st.header("Product Click Prediction Dashboard")

    # Load model
    model = joblib.load("regression_model.pkl")

    st.write("Upload a CSV file with columns: timestamp, product_type, price, clicks")

    uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

    if uploaded_file is not None:
        data = pd.read_csv(uploaded_file)

        st.subheader("Uploaded Data")
        st.dataframe(data)

        # Convert timestamp and extract time-based features
        if 'timestamp' in data.columns:
            try:
                data['timestamp'] = pd.to_datetime(data['timestamp'])
                data['hour_of_day'] = data['timestamp'].dt.hour
                data['day_of_week'] = data['timestamp'].dt.dayofweek
                data['is_weekend'] = data['day_of_week'].apply(lambda x: 1 if x >= 5 else 0)
            except Exception as e:
                st.error(f"Error processing timestamp: {e}")
                st.stop()
        else:
            st.error("Missing 'timestamp' column.")
            st.stop()

        # Required columns for prediction
        required_cols = ['product_type', 'price', 'hour_of_day', 'day_of_week', 'is_weekend']
        if not all(col in data.columns for col in required_cols):
            st.error(f"Required columns missing: {required_cols}")
            st.stop()

        # Predict
        data["Predicted Clicks"] = model.predict(data[required_cols])

        st.subheader("Predictions")
        st.dataframe(data)

        st.metric("Average Predicted Clicks", round(data["Predicted Clicks"].mean(), 2))

        # GRAPH 1: Avg Predicted Clicks by Product Type 
        st.subheader("1. Avg Predicted Clicks by Product Type")
        avg_by_type = data.groupby("product_type")["Predicted Clicks"].mean().reset_index()
        st.bar_chart(avg_by_type.set_index("product_type"))

        # GRAPH 2: Predicted Clicks Over Time
        if 'timestamp' in data.columns:
            st.subheader("2. Predicted Clicks Over Time")
            time_df = data.copy()
            time_df['timestamp'] = pd.to_datetime(time_df['timestamp'])
            time_df = time_df.sort_values("timestamp")
            st.line_chart(time_df.set_index("timestamp")["Predicted Clicks"])

        # GRAPH 3: Actual vs Predicted Clicks 
        if 'clicks' in data.columns:
            st.subheader("3. Actual vs Predicted Clicks")
            st.line_chart(data[["clicks", "Predicted Clicks"]])

        # GRAPH 4: Price Distribution Histogram 
        st.subheader("4. Product Price Distribution")
        st.bar_chart(data["price"].value_counts().sort_index())

        # GRAPH 5: Boxplot (Predicted Clicks per Product Type)
        st.subheader("5. Predicted Clicks Variation by Product Type")
        box_data = data[["product_type", "Predicted Clicks"]]
        box_chart = alt.Chart(box_data).mark_boxplot().encode(
            x="product_type:N",
            y="Predicted Clicks:Q"
        )
        st.altair_chart(box_chart, use_container_width=True)

        # GRAPH 6: Heatmap (Hour vs Product Type)
        st.subheader("6. Heatmap: Avg Predicted Clicks by Hour and Product Type")
        heat_data = data.groupby(["hour_of_day", "product_type"])["Predicted Clicks"].mean().reset_index()
        heatmap = alt.Chart(heat_data).mark_rect().encode(
            x='hour_of_day:O',
            y='product_type:N',
            color='Predicted Clicks:Q'
        ).properties(width=700)
        st.altair_chart(heatmap, use_container_width=True)

    else:
        st.info("Please upload a CSV file to make predictions.")

# TAB 2: PDF CHATBOT
with tab2:
    st.header("Ask Your PDF Chatbot")

    # Load vector index and supporting files
    index = faiss.read_index("faiss_index/index.faiss")

    with open("faiss_index/chunks.pkl", "rb") as f:
        chunks = pickle.load(f)

    with open("faiss_index/meta.pkl", "rb") as f:
        sources = pickle.load(f)

    # Load models
    embed_model = SentenceTransformer("all-MiniLM-L6-v2")
    qa_model = pipeline("question-answering", model="distilbert-base-uncased-distilled-squad")

    # UI
    selected_topic = st.selectbox("Choose document:", ["All", "python.pdf", "sql.pdf", "ml.pdf"])
    question = st.text_input("Ask a question")

    if question:
        q_embedding = embed_model.encode([question])
        q_embedding = np.array(q_embedding).astype("float32")

        top_k = 5
        distances, indices = index.search(q_embedding, top_k)

        context = ""
        used_sources = {}

        for i in indices[0]:
            if selected_topic == "All" or sources[i] == selected_topic:
                context += chunks[i] + "\n"
                used_sources[int(i)] = sources[i]

        if not context:
            st.warning("No relevant content found in the selected document.")
        else:
            result = qa_model(question=question, context=context)
            st.subheader("Answer")
            st.success(result["answer"].strip())

            with st.expander("Context Used"):
                st.write(context[:1500] + "..." if len(context) > 1500 else context)

            with st.expander("Sources"):
                st.write(used_sources)
