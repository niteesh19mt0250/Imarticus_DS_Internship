import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# Step 1: Load and prepare data
data = pd.read_csv("simulated_data_1.csv")

# Step 2: Convert timestamp and extract features
data['timestamp'] = pd.to_datetime(data['timestamp'])
data['hour_of_day'] = data['timestamp'].dt.hour
data['day_of_week'] = data['timestamp'].dt.dayofweek
data['is_weekend'] = (data['day_of_week'] >= 5).astype(int)

# Step 3: Optional - Clip extreme outliers
data['clicks'] = data['clicks'].clip(upper=20)

# Step 4: Define features and target
features = ['product_type', 'price', 'hour_of_day', 'day_of_week', 'is_weekend']
X = data[features]
y = data['clicks']

# Step 5: Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), ['product_type']),
        ('num', StandardScaler(), ['price', 'hour_of_day', 'day_of_week', 'is_weekend'])
    ]
)

# Step 6: Build pipeline
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', Ridge(alpha=0.5))
])

# Step 7: Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Step 8: Train the model
model.fit(X_train, y_train)

# Step 9: Evaluate
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse:.2f}")
print(f"R² Score: {r2:.2f}")

# Step 10: Save model
joblib.dump(model, "regression_model.pkl")
print("Model saved to 'regression_model.pkl'")
