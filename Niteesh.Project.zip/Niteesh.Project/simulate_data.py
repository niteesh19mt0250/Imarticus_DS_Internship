import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import os

# Define simulation parameters
product_list = ['Smartphone', 'Laptop', 'Headphones', 'Camera', 'Smartwatch']

# Price ranges for different products
price_ranges = {
    'Smartphone': (300, 1000),
    'Laptop': (500, 1500),
    'Headphones': (30, 300),
    'Camera': (200, 1200),
    'Smartwatch': (100, 500)
}

# Define base click logic (improves correlation)
def calculate_clicks(product, price, hour):
    # Product baseline
    base_clicks = {
        'Smartphone': 10,
        'Laptop': 8,
        'Headphones': 6,
        'Camera': 5,
        'Smartwatch': 7
    }[product]

    # Inverse relation with price (normalized)
    min_price, max_price = price_ranges[product]
    price_score = 1 - ((price - min_price) / (max_price - min_price))

    # Hour-based popularity (peak: 18–22)
    if 18 <= hour <= 22:
        hour_score = 1.2
    elif 9 <= hour <= 17:
        hour_score = 1.0
    else:
        hour_score = 0.8

    # Final click value + noise
    clicks = base_clicks * price_score * hour_score + random.uniform(-2, 2)
    return max(1, min(round(clicks), 20))  # clamp between 1–20

# Safe CSV save function
def safe_save(df, base_name="simulated_data.csv"):
    i = 1
    filename = base_name
    while os.path.exists(filename):
        try:
            with open(filename, 'a'):
                break
        except PermissionError:
            filename = f"simulated_data_{i}.csv"
            i += 1
    df.to_csv(filename, index=False)
    print(f" Data saved to '{filename}'.")

# Generate synthetic dataset
def run_simulation(records=10000):
    print(" Starting simulation...")

    data = []

    base_time = datetime(2025, 4, 9, 0, 0, 0)  # fixed date for reproducibility

    for i in range(records):
        product = random.choice(product_list)
        price = round(random.uniform(*price_ranges[product]), 2)
        timestamp = base_time + timedelta(seconds=i * 30)  # new row every 30 sec
        hour = timestamp.hour

        clicks = calculate_clicks(product, price, hour)

        data.append({
            'timestamp': timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            'product_type': product,
            'price': price,
            'clicks': clicks
        })

    df = pd.DataFrame(data)
    safe_save(df)

# Run the simulation
if __name__ == "__main__":
    run_simulation(records=10000)
